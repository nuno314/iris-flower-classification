clear all;
clc;
xx = [-2;-1;0;1;2;3;4]
yy = [24;1;4;3;-8;-11;36]
I = 7.2
[I1,delta_I1,I2,delta_I2,I3,delta_I3] = tichPhanSo_3_N_C(xx,yy,I)